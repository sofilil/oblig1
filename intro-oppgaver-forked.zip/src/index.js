//Hentet hjelp fra løsningsforslag, w3schools, og oppgaver fra forrige semester.

// Oppgave 1
const text1 = document.getElementById("remove");
const removeButton = document.getElementById("remove-btn");

function removeText() {
  text1.innerHTML = null;
}

removeButton.addEventListener("click", removeText);

// Oppgave 2
const text2 = document.getElementById("change");
const changeButton = document.getElementById("change-btn");

function changeText() {
  text2.innerHTML = "Dette var vanskelig.";
}

changeButton.addEventListener("click", changeText);

// Oppgave 3
const inputText = document.getElementById("input-text");
const input = document.getElementById("input");

function removeText3() {
  inputText.innerHTML = null;
}

removeText3();

function writeText(event) {
  let letter = event.key;
  inputText.innerHTML += letter;
}

input.addEventListener("keyup", writeText);

// Oppgave 4
const myList = ["item one", "item two", "item three"];

const ul = document.getElementById("ul");
const listButton = document.getElementById("write-list");

function writeList() {
  myList.forEach((listElement) => (ul.innerHTML += `<li>${listElement}</li>`));
}

listButton.addEventListener("click", writeList);

// Oppgave 5
const text = document.getElementById("text");
const createButton = document.getElementById("create");
const select = document.getElementById("select");
const placeHolder = document.getElementById("placeholder");

function addElement() {
  const element = select.value;
  const message = text.value;

  placeHolder.innerHTML += `<${element}>${message}</${element}>`;
}

createButton.addEventListener("click", addElement);

// Oppgave 6
const removeLiBtn = document.getElementById("remove-li");
const liEl = document.getElementById("list");

function removeLiEl() {
  const lastElement = liEl.lastElementChild;
  if (lastElement) {
    liEl.removeChild(lastElement);
  }
}

removeLiBtn.addEventListener("click", removeLiEl);

// Oppgave 7
const nameInput = document.getElementById("name");
const orderButton = document.getElementById("order");

function handleKeyUp() {
  const name = nameInput.value;
  if (name && name.length >= 4) {
    orderButton.disabled = true;
    orderButton.style = "border: 1px solid red";
  } else {
    orderButton.disabled = false;
    orderButton.style = "border: 1px solid black";
  }
}

nameInput.addEventListener("keyup", handleKeyUp);

// Oppgave 8
const ulParent = document.querySelector(".children");
const ulParentChildren = ulParent.querySelectorAll("li");
const colorButton = document.getElementById("color");

function addBorder() {
  Array.from(ulParentChildren).forEach((li, index) => {
    if ((index + 1) % 2 === 0) {
      li.style = "border: 2px solid pink";
    } else {
      li.style = "border: 2px solid green";
    }
  });
}

colorButton.addEventListener("click", addBorder);
